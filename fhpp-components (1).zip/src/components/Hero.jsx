export default function Hero() {
  return (
    <section className="bg-blue-600 text-white">
      <div className="container mx-auto px-6 py-20 md:py-32 text-center">
        <h1 className="text-4xl md:text-6xl font-extrabold leading-tight mb-4">
          Clear, Simple, Affordable Health Insurance
        </h1>
        <p className="text-lg md:text-xl text-blue-100 max-w-3xl mx-auto mb-8">
          We help Floridians find the perfect health plan. No jargon, no hassle—just expert guidance and support.
        </p>
        <a href="#contact" className="bg-white text-blue-600 font-bold py-3 px-8 rounded-full hover:bg-blue-100 transition-transform duration-300 transform hover:scale-105 shadow-lg">
          Get a Free Quote
        </a>
      </div>
    </section>
  );
}