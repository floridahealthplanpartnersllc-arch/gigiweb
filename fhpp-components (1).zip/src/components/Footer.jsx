import { Phone, Mail, MapPin } from 'lucide-react';

const navLinks = [
  { href: "#about", label: "About Us" },
  { href: "#plans", label: "Our Plans" },
  { href: "#testimonials", label: "Testimonials" },
  { href: "#contact", label: "Contact" },
];

export default function Footer() {
  return (
    <footer className="bg-gray-800 text-white">
      <div className="container mx-auto px-6 py-12">
        <div className="grid md:grid-cols-3 gap-8">
          <div>
            <h4 className="text-lg font-bold mb-4">Florida Health Plan Partners</h4>
            <p className="text-gray-400">Your dedicated partner in navigating the complexities of health insurance. Serving all of Florida.</p>
          </div>
          <div>
            <h4 className="text-lg font-bold mb-4">Contact Info</h4>
            <ul className="space-y-2 text-gray-400">
              <li className="flex items-center"><MapPin className="w-5 h-5 mr-3 text-blue-400" /> 123 Health St, Miami, FL 33101</li>
              <li className="flex items-center"><Mail className="w-5 h-5 mr-3 text-blue-400" /> <a href="mailto:contact@fhpp.com" className="hover:text-white">contact@fhpp.com</a></li>
              <li className="flex items-center"><Phone className="w-5 h-5 mr-3 text-blue-400" /> <a href="tel:1-800-555-1234" className="hover:text-white">(800) 555-1234</a></li>
            </ul>
          </div>
          <div>
            <h4 className="text-lg font-bold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              {navLinks.map(link => (
                <li key={link.href}><a href={link.href} className="text-gray-400 hover:text-white">{link.label}</a></li>
              ))}
            </ul>
          </div>
        </div>
        <div className="mt-12 border-t border-gray-700 pt-8 text-center text-gray-500">
          <p>&copy; {new Date().getFullYear()} Florida Health Plan Partners. All Rights Reserved.</p>
          <p className="text-sm mt-2">This is a solicitation for insurance. A licensed agent may contact you.</p>
        </div>
      </div>
    </footer>
  );
}