export const testimonials = [
  {
    name: "Sarah L.",
    location: "Miami, FL",
    comment: "They made health insurance simple. Perfect, affordable plan for my family.",
    rating: 5,
  },
  {
    name: "David R.",
    location: "Orlando, FL",
    comment: "Fantastic plan for my business. Highly recommended!",
    rating: 5,
  },
  {
    name: "Maria G.",
    location: "Tampa, FL",
    comment: "I now have a Medicare plan that covers all my needs.",
    rating: 5,
  },
];