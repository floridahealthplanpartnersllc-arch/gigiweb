import { Heart, Users, Shield } from 'lucide-react';

export const plans = [
  {
    icon: <Heart className="w-12 h-12 text-blue-600 mb-4" />,
    name: "Individual & Family",
    description: "Affordable health plans tailored to meet the needs of you and your family.",
    features: ["Low monthly premiums", "Wide network", "Preventive care", "Dental and vision"],
  },
  {
    icon: <Users className="w-12 h-12 text-blue-600 mb-4" />,
    name: "Small Business",
    description: "Flexible and cost-effective group insurance solutions for your employees.",
    features: ["Group rates", "HSA/HRA options", "Wellness programs", "Easy admin"],
  },
  {
    icon: <Shield className="w-12 h-12 text-blue-600 mb-4" />,
    name: "Medicare Advantage",
    description: "Comprehensive plans offering more than Original Medicare.",
    features: ["$0 premium plans", "Drug coverage", "Fitness benefits", "Hearing and vision"],
  },
];